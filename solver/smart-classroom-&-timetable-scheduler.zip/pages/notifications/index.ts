
export { default } from './ui/NotificationsPage';
